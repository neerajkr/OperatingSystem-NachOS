CS330A Assignment1:
---------------------
Sep25, 2016
-----------------
Group 29
-----------


SYScall Implementation Explanation:
-----------------------------------------

SYScall_GetReg:

->the argument of this system call is stored in reg 4, from where we read the register no. whose content we want to display.
->the content of the register is retrieved using ReadRegister() function and is returned in register 2 using WriteRegister().

SYScall_GetPA:

->Input is the virtual address which is read from register 4.
->calculate the virtual page number and check the 3 validity conditions. If invalid, return -1 in register 2.
->If valid, calculate the physical address using physical page no obtained from NachOSpageTable in register 2.

SYScall_GetPID:

->Created public method in class NachOSThread to access the thread's pid (private).
->first thread is assigned pid=1, and every time a new thread is created, it is assigned pid in increasing order.

SYScall_GetPPID:

->Created public method in class NachOSThread to access the thread's pid (private).
->First thread's ppid is 0 (parent = NULL), and every time a new thread is created, the current thread's pid is assigned as its ppid.

SYScall_Time:

->A Statistics class object 'stats' is defined in system.h. It contains a member called totalTicks which gives the total ticks at present.

SYScall_Yield:

->NachoSThread class contains a method YieldCPU() which is called for this system call.

SYScall_NumInstr:

->A new variable no_instr is added to the class NachOSThread which is initialised to 0.
->After each user instruction is executed, no_instr is incremented inside the function OneTick() in file interrupt.cc.

SYScall_Exec:

->Read the value of register 4 in FileNameMemoryAddr variable of type int. This variable represents the start of virtual address, where filename is stored.
->Translated the value of FileNameMemoryAddr to a character array “filename” using Readmem() function of machine class . We translated one byte at a time.
-> We opened the file using filesystem, created a ProcessAddrSpace, set the initial register values, load page table register and run the executable. We basically, mimicked what the StartUserProcess() function does.
->To ensure not to reuse or overwrite the existing address space, we have modified the ProcessAddrSpace function in addrspace.cc file and used a global variable PhysicalPagesUsed, that will make sure not to use already used space.
-> Also, we have not advanced the program counter, since the system_call_Exec() call never returns and must start execution at the beginning of the passed executable.

SYScall_sleep:

-> We read the number of ticks in the variable NumberOfTicks and if the value if this variable is 0, we have simply called the YieldCPU() function of current thread.
->Otherwise, we have inserted the current thread in a global list created by us, namely SleepingThreads declared in threads/system.h file. We have inserted in sorted order with key value as current tick (totalTicks) plus the NumberOfTicks. For inserting, we have used SortedInsert() function defined in file list.cc.
->To wake up the sleeping threads, we have modified the TimerInterruptHandler() function in system.cc file so that once the key value associated with any sleeping thread is less than current number of ticks during execution of this function, we have scheduled that thread.
->Then, we have simply called the function PutThreadToSleep() in exception.cc to sleep the current thread until it is called again to schedule.
->Finally, we have advanced the program counter by one as a general case.


SYScall_Join:

->The pid of the child thread that the current thread would wait for is read into the variable ‘child_pid’.
->Each thread stores 3 extra variables declared and initialised in the NachOSThread constructor in the file thread.cc: ‘parent’-pointer to its parent thread, ‘children_list’-a list of all of its child threads sorted according to their pids, ‘children_exit_code’-a list of the exit code of all of its children that have finished their execution and have exited, sorted according to their pids.
-> a global array ‘arr’ with index ’arr_index’ is used to store the pids of all the threads whose parents are waiting for them to finish their execution (via the Join system call).
->’search_key’ searches if there exists an item in the list with the passed argument as its key and returns a pointer to it. It is defined in the file list.cc. 
->If the passed argument pid dos not correspond to one of its children, the system call returns ‘-1’. Otherwise, it checks whether the child thread has already exited. If so, its exit code is returned which is stored in the address corresponding to the integer pointer ‘check_exit_ptr’ otherwise, the pid of the child thread(child_pid) is added to the global array ‘arr’ and the parent thread(current thread) is put to sleep.
-> The value of -9999 is used to check if the return value was 0 as 0 could clash with the pointer being NULL.

SYScall_Exit:

->the exit code of the exiting thread is read into the integer variable ‘ExitCode’.
->the exit code of this thread is added to the ‘children_exit_code’ list of its parent thread for use in the Join system call.
->if the pid of this thread is present in the global array ‘arr’ (that is its parent had called the Join system call with the pid of this thread as the argument) then its parent thread is put in the ready queue from the sleep state by calling the function ‘ThreadIsReadyToRun’.
->The current thread finishes its execution and deallocates its address space by calling the ‘FinishThread()’ function.

SYScall_Fork:

>A new thread and address space is created for the child. The new constructor ProcessAddreSpace() defined in addrspace.cc sets the pageTable for the child and copies the contents of parent space to the child space.
->The pid of the child thread is added to the ‘children_list’ list variable of the parent thread which stores the list of all of its children for use in the Join system call.
->The parent's register set is copied into child's saved user context using the function SaveUserState() defined in NachOSThread class.
->0 is returned to child and its program counter is incremented so that it starts execution as if it has just returned from Fork. This is done using a new method defined in NachOSThread class called WriteReg().
->ThreadFork() method of NachOSThread class is called with arguments as PrepareContext() function and the thread child.
->PrepareContext() function defined in thread.cc, deletes any thread which are to be destroyed, restores the registers and address space of child thread and calls the Run() function of machine class.
->Finally, the child's pid is returned to the parent and it's PC is incremented.











