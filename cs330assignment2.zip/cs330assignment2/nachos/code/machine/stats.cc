// stats.h 
//	Routines for managing statistics about Nachos performance.
//
// DO NOT CHANGE -- these stats are maintained by the machine emulation.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "utility.h"
#include "stats.h"

//----------------------------------------------------------------------
// Statistics::Statistics
// 	Initialize performance metrics to zero, at system startup.
//----------------------------------------------------------------------

Statistics::Statistics()
{
    totalTicks = idleTicks = systemTicks = userTicks = 0;
    numDiskReads = numDiskWrites = 0;
    numConsoleCharsRead = numConsoleCharsWritten = 0;
    numPageFaults = numPacketsSent = numPacketsRecvd = 0;


    StatsAlgo=1;
    MaxCPUBurst=0;
    MinCPUBurst=9999999;
    TotalNumCPUBurst=0;
    SumCPUBurst=0;
    SqrSumCPUBurst=0;
    SumBurstErrors=0;

    MaxThreadCompletion=0;
    MinThreadCompletion=9999999;
    SumThreadCompletion=0;
    SqrSumThreadCompletion=0;
    SumWaitingTime=0;
    StartTimeCurrentBurst=0;

    TotalNumThreads=0;
}


void
Statistics::StatsForBurstError(int PredictedBurst){
    int ActualBurst=totalTicks- StartTimeCurrentBurst;
    if(ActualBurst>0){
        if((ActualBurst- PredictedBurst )>0)
            SumBurstErrors+=(ActualBurst- PredictedBurst );
        else 
            SumBurstErrors-=(ActualBurst- PredictedBurst );   
    } 
}

void
Statistics::StatsWhenBurstEnds(){
    int LastBurstLength=totalTicks- StartTimeCurrentBurst;
    if(LastBurstLength==0)  return;
    else{
        if(MaxCPUBurst<LastBurstLength) MaxCPUBurst=LastBurstLength;
        if(MinCPUBurst>LastBurstLength) MinCPUBurst=LastBurstLength;
        TotalNumCPUBurst++;
        SumCPUBurst=SumCPUBurst+LastBurstLength;
        SqrSumCPUBurst=SqrSumCPUBurst+LastBurstLength*LastBurstLength;
        return;
    }
}


void 
Statistics::StatsForExitingThread(){

    long long int LastThreadCompletionTime=totalTicks;
    if(MinThreadCompletion>LastThreadCompletionTime)    MinThreadCompletion=LastThreadCompletionTime;
    if(MaxThreadCompletion<LastThreadCompletionTime)    MaxThreadCompletion=LastThreadCompletionTime;
    SumThreadCompletion+=LastThreadCompletionTime;
    SqrSumThreadCompletion+=LastThreadCompletionTime*LastThreadCompletionTime;
    TotalNumThreads++;
    return;
}


void
Statistics::SetCurrentBurstStartTime(){
    StartTimeCurrentBurst=totalTicks;
}

//----------------------------------------------------------------------
// Statistics::Print
// 	Print performance metrics, when we've finished everything
//	at system shutdown.
//----------------------------------------------------------------------

void
Statistics::Print()
{

    printf("======Threads Related Stats=======\n");

    printf("minimum thread completion time: %d\n", MinThreadCompletion);
    printf("maximum thread completion time: %d\n", MaxThreadCompletion);
    double AvgWaitingTime = SumWaitingTime/((TotalNumThreads+1)*1.0);
    printf("AvgWaitingTime: %.2lf\n", AvgWaitingTime);  

    double AvgThreadCompletion = SumThreadCompletion/(TotalNumThreads*1.0);
    printf("average thread completion time: %.2lf\n", AvgThreadCompletion);
    double VarianceThreadCompletion = SqrSumThreadCompletion/(TotalNumThreads*1.0) - (AvgThreadCompletion*AvgThreadCompletion);
    printf("variance of thread completion: %.2lf\n", VarianceThreadCompletion);
    printf("total number of threads executed: %d\n", TotalNumThreads);

    printf("=======CPU Related Data======================\n");
    
    printf("CPU utilization : %0.2f\n", 100*SumCPUBurst/(totalTicks*1.0));
    printf("Total CPU busy time : %d\n", totalTicks - idleTicks);
    printf("Sum of all cpu bursts : %d\n",SumCPUBurst);
    printf("Total execution time : %d\n", totalTicks);

    printf("MinCPUBurst: %d\n",MinCPUBurst);
    printf("MaxCPUBurst: %d\n", MaxCPUBurst);
    double AvgCPUBurst =  SumCPUBurst/(TotalNumCPUBurst*1.0); 
    printf("AvgCPUBurst: %.2lf\n", AvgCPUBurst);
    double VarianceCPUBurst = SqrSumCPUBurst/(TotalNumCPUBurst*1.0)-(AvgCPUBurst*AvgCPUBurst) ;
    printf("VarianceCPUBurst: %.2lf\n", VarianceCPUBurst);
    printf("TotalNumCPUBurst : %d\n", TotalNumCPUBurst);
    if(StatsAlgo == 2)
        printf("Burst prediction error percentage: %.2f\n", 100*SumBurstErrors/(SumCPUBurst*1.0));
    

    printf("=============Default Stats Earlier Provided=================\n");


    printf("Ticks: total %d, idle %d, system %d, user %d\n", totalTicks, 
	idleTicks, systemTicks, userTicks);
    printf("Disk I/O: reads %d, writes %d\n", numDiskReads, numDiskWrites);
    printf("Console I/O: reads %d, writes %d\n", numConsoleCharsRead, 
	numConsoleCharsWritten);
    printf("Paging: faults %d\n", numPageFaults);
    printf("Network I/O: packets received %d, sent %d\n", numPacketsRecvd, 
	numPacketsSent);


}
